import {world,system} from '@minecraft/server';

// HP above mobs: a mob that takes damage shows its HP over its head for SHOW_MS ("HP 12 / 20" and a bar of ten
// marks), then its own name (or nothing) comes back. It is done with the name tag, which the game shows over a mob.
// A named mob does not despawn, so the HP tag is always removed again: mobs showing it carry the tag TAG, and any
// left over (the area unloaded before the timer) are cleaned when seen again. Players are left alone.
export const SHOW_MS=5000,TAG='ct_hp';
const NAME_KEY='cooptown:own_name';
// the keeper's box, the warehouse vault and the おんぶ seat are not mobs (the box's name is its chest screen's title)
const SKIP=new Set(['minecraft:player','minecraft:armor_stand','minecraft:item','minecraft:xp_orb','minecraft:arrow','minecraft:painting','cooptown:villager','cooptown:deposit_box','cooptown:pack_box','cooptown:warehouse_vault','cooptown:onbu_seat']);
/** The HP text: "HP 12 / 20" and ten marks, green / yellow / red by the share left. */
export function hpText(hp,max,name=''){
 const share=max>0?Math.max(0,Math.min(1,hp/max)):0,full=Math.round(share*10),col=share>.5?'§a':share>.25?'§e':'§c';
 return `${name?name+'\n':''}${col}HP ${Math.ceil(hp)} / ${Math.ceil(max)}\n${col}${'|'.repeat(full)}§8${'|'.repeat(10-full)}`;
}
export function installMobHp(){
 const shown=new Map(); // entity id -> {entity, until}
 const restore=e=>{try{const own=e.getDynamicProperty(NAME_KEY);e.nameTag=typeof own==='string'?own:'';e.setDynamicProperty(NAME_KEY,undefined);e.removeTag(TAG);}catch{}};
 const show=e=>{
  if(!e?.isValid||SKIP.has(e.typeId))return;
  const h=e.getComponent('minecraft:health');if(!h)return;
  if(!e.hasTag(TAG)){try{e.setDynamicProperty(NAME_KEY,e.nameTag??'');e.addTag(TAG);}catch{return;}}
  const own=e.getDynamicProperty(NAME_KEY);
  if(h.currentValue<=0){shown.delete(e.id);restore(e);return;}
  try{e.nameTag=hpText(h.currentValue,h.effectiveMax,typeof own==='string'?own:'');}catch{}
  shown.set(e.id,{entity:e,until:Date.now()+SHOW_MS});
 };
 world.afterEvents.entityHurt.subscribe(({hurtEntity})=>show(hurtEntity));
 // healing (regeneration, a potion) while the tag shows keeps it up to date; then it goes away
 system.runInterval(()=>{
  const now=Date.now();
  for(const [id,s] of shown){
   if(!s.entity.isValid){shown.delete(id);continue;}
   if(now>=s.until){shown.delete(id);restore(s.entity);continue;}
   const h=s.entity.getComponent('minecraft:health');const own=s.entity.getDynamicProperty(NAME_KEY);
   if(h)try{s.entity.nameTag=hpText(h.currentValue,h.effectiveMax,typeof own==='string'?own:'');}catch{}
  }
 },10);
 // HP tags left over from before (unloaded areas, a restart)
 const clean=e=>{if(e.hasTag?.(TAG)&&!shown.has(e.id))restore(e);};
 world.afterEvents.entityLoad?.subscribe(({entity})=>clean(entity));
 system.runInterval(()=>{for(const d of ['overworld','nether','the_end'])try{for(const e of world.getDimension(d).getEntities({tags:[TAG]}))clean(e);}catch{}},200);
}
