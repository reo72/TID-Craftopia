import {world,system} from '@minecraft/server';

// Town music (asked 2026-10-27): while a player is in the first town (within TOWN_BGM.radius of the town's base, set by
// staff in the admin screen: 街 > 拠点をここに), calm game tracks play for them one after another, with a short rest
// between; leaving the town stops it. The tracks are the game's own music files, played through the pack's sound
// events (RP sounds/sound_definitions.json: cooptown.town_bgm.<name>, category music: the music volume slider
// applies). /cooptown:bgm turns it off / on for oneself.
export const TOWN_BGM={radius:72,leave:84,gapSec:15,everyTicks:40,offKey:'cooptown:bgm_off',
 // [file name in the game's sounds/music/game, length in seconds]
 tracks:[['sweden',230],['an_ordinary_day',331],['comforting_memories',275],['pokopoko',305],['komorebi',288],['one_more_day',279],['left_to_bloom',343],['mice_on_venus',281],['home',380],['fireflies',156]]};
export const bgmSound=name=>'cooptown.town_bgm.'+name;
/** Whether a place is in the town: same dimension and within r (x / z) of the base. */
export function inTown(base,dim,loc,r=TOWN_BGM.radius){
 if(!base)return false;
 if((base.dimension??'minecraft:overworld')!==dim)return false;
 return Math.hypot(loc.x-base.x,loc.z-base.z)<=r;
}
/** The next track: random, never the one just played. */
export function nextTrack(last,random=Math.random){
 const list=TOWN_BGM.tracks.filter(([n])=>n!==last);return list[Math.floor(random()*list.length)]??TOWN_BGM.tracks[0];
}
const isOff=player=>{try{return player.getDynamicProperty(TOWN_BGM.offKey)===true;}catch{return false;}};
export function installTownBgm({game}){
 const playing=new Map(); // player id -> {name, until (ms)}
 const stop=player=>{const s=playing.get(player.id);playing.delete(player.id);if(s)try{player.runCommand(`stopsound @s ${bgmSound(s.name)}`);}catch{}};
 const start=(player,last)=>{const [name,secs]=nextTrack(last);try{player.playSound(bgmSound(name),{volume:1});}catch{}playing.set(player.id,{name,until:Date.now()+secs*1000});};
 system.runInterval(()=>{
  let base;try{base=game.peek(d=>d.town?.location);}catch{}
  const now=Date.now();
  for(const player of world.getAllPlayers()){
   const s=playing.get(player.id);
   const here=!isOff(player)&&inTown(base,player.dimension.id,player.location,s?TOWN_BGM.leave:TOWN_BGM.radius);
   if(!here){if(s)stop(player);continue;}
   if(!s)start(player);
   else if(now>=s.until+TOWN_BGM.gapSec*1000)start(player,s.name); // the next one after a short rest
  }
 },TOWN_BGM.everyTicks);
 world.afterEvents.playerLeave.subscribe(({playerId})=>playing.delete(playerId));
 return {toggle(player){const off=!isOff(player);try{player.setDynamicProperty(TOWN_BGM.offKey,off);}catch{}if(off)stop(player);
  player.sendMessage(off?'§7街のBGMをオフにしました（/cooptown:bgm でオンに戻せます）。':'§a街のBGMをオンにしました。');}};
}
