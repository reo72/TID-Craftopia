import {JOB_SPECIAL_NAMES} from './special-config.js';
import {EXTRA_ITEM_NAMES} from './item-names-extra.js';
import {CAN_NAMES} from './watering-config.js';
import {TOOL_NAMES} from './job-tools-config.js';
import {PAN_ITEM_NAMES} from './frying-pan.js';
import {DISHES} from './food-config.js';
import {POTIONS} from './potion-config.js';
import {FOOD_CATALOG} from './food-catalog.js';
import {FISH_SPECIES} from './fish-species.js';
import {SPECIAL_NAMES,SPECIAL_RECIPES} from './cooperation-config.js';
import {BASIC_RECIPES,JOB_VANILLA_RECIPES,WORKBENCH_NAMES,WORKBENCH_RULES,MATERIAL_VALUES,GROUP_VALUES,GROUPS} from './workbench-config.js';
// Initial play-test rules. Keep balance changes here, separate from persistence/UI.
export const RULES={secondaryLevel:20,jobChangeCost:100,coinCap:1000000000,dailyCoins:100,dailyXp:60,dailyBonus:150,townBatch:16,townCoins:10};
// 調合師 was split off 料理人 (once one job, 料理人・調合師): it comes last so the other jobs keep their numbers
// the jobs of the design (Notion「職業システム」): 冒険家 replaces 木こり and 鉱夫 (2026-10-19), 畜産農家 merged into 農家 (2026-10-20), 付与術師
// is now 付与術師 (was エンチャンター until 2026-10-22); no job (未選択) shows as ニート
export const JOBS=['冒険家','農家','鍛冶師','料理人','付与術師','釣り師','調合師'];
/** Old job names in saved data -> the current ones (game-engine.js renames them when it reads the save). */
export const RENAMED_JOBS={'料理人・調合師':'料理人','木こり':'冒険家','鉱夫':'冒険家','エンチャンター':'付与術師','畜産農家':'農家'};
/** How a job shows: 未選択 is ニート. */
export const jobLabel=job=>!job||job==='未選択'?'ニート':job;
export const MATERIALS=[['minecraft:oak_log','オークの原木'],['minecraft:iron_ingot','鉄インゴット'],['minecraft:bread','パン'],['minecraft:cobblestone','丸石'],['minecraft:wheat','小麦'],['minecraft:cod','生のタラ']];
const BASE_NAMES={...SPECIAL_NAMES,...Object.fromEntries([...MATERIALS,['minecraft:oak_planks','オークの板材'],['minecraft:raw_iron','鉄の原石'],['minecraft:coal','石炭'],['minecraft:hay_block','干草の俵'],['minecraft:stick','棒'],['minecraft:iron_pickaxe','鉄のツルハシ'],['minecraft:paper','紙'],['minecraft:leather','革'],['minecraft:book','本'],['minecraft:cooked_cod','焼きタラ'],['minecraft:lantern','ランタン'],['minecraft:painting','絵画'],['minecraft:flower_pot','植木鉢'],['minecraft:poppy','ポピー'],['minecraft:name_tag','名札'],['cooptown:guidebook','メニュー'],['minecraft:lapis_lazuli','ラピスラズリ'],['minecraft:glass_bottle','ガラス瓶']])};
export const ORDERS=[{name:'街へ木材を届けよう',item:'minecraft:oak_log',amount:32,coins:160,skill:'gather'},{name:'鉄インゴットの募集',item:'minecraft:iron_ingot',amount:8,coins:200,skill:'mine'},{name:'探索用の料理を届けよう',item:'minecraft:bread',amount:8,coins:120,skill:'craft'}];
// Workbench-only names are for display; the tradable list stays the original material set.
export const ITEM_NAMES={...EXTRA_ITEM_NAMES,...WORKBENCH_NAMES,...BASE_NAMES,...JOB_SPECIAL_NAMES,...CAN_NAMES,...TOOL_NAMES,...PAN_ITEM_NAMES,'cooptown:guidebook_open':'案内手帳','cooptown:admin_book':'運営の手帳','cooptown:recipe_scroll':'レシピの巻物','minecraft:emerald':'エメラルド','minecraft:rotten_flesh':'腐った肉','minecraft:prismarine_crystals':'プリズマリンクリスタル','minecraft:bamboo':'竹','minecraft:ice':'氷','minecraft:torch':'松明','minecraft:bone_meal':'骨粉','minecraft:brick':'レンガ','minecraft:green_dye':'緑の染料','minecraft:blue_dye':'青の染料','minecraft:lime_dye':'黄緑の染料','minecraft:cyan_dye':'水色の染料','minecraft:purple_dye':'紫の染料','minecraft:pink_dye':'ピンクの染料','minecraft:gray_dye':'灰色の染料','minecraft:brown_dye':'茶色の染料','minecraft:yellow_dye':'黄色の染料',
 ...Object.fromEntries(Object.entries(DISHES).map(([k,d])=>['cooptown:'+k,d[0]])),...Object.fromEntries(POTIONS.map(p=>[p.id,p.name])),
 ...Object.fromEntries(FOOD_CATALOG.map(e=>[e.id,e.name])),...Object.fromEntries(FISH_SPECIES.map(s=>[s.id,s.name])),water:'水入り瓶'};
export const TRADE_ITEMS=Object.keys(BASE_NAMES).filter(id=>!['cooptown:guidebook','minecraft:iron_pickaxe'].includes(id));
export const RECIPES=[
 {name:'木材加工',job:'冒険家',inputs:[['minecraft:oak_log',4]],output:['minecraft:oak_planks',16]},
 {name:'鉄の精錬',job:'鍛冶師',inputs:[['minecraft:raw_iron',4],['minecraft:coal',1]],output:['minecraft:iron_ingot',4]},
 {name:'干草の俵',job:'農家',reversible:true,inputs:[['minecraft:wheat',9]],output:['minecraft:hay_block',1]},
 {name:'鉄のツルハシ',job:'鍛冶師',inputs:[['minecraft:iron_ingot',3],['minecraft:stick',2]],output:['minecraft:iron_pickaxe',1]},
 {name:'パン作り',job:'料理人',inputs:[['minecraft:wheat',3]],output:['minecraft:bread',1]},
 {name:'本作り',job:'付与術師',inputs:[['minecraft:paper',3],['minecraft:leather',1]],output:['minecraft:book',1]},
 {name:'焼き魚',job:'釣り師',inputs:[['minecraft:cod',4],['minecraft:coal',1]],output:['minecraft:cooked_cod',4]},
 ...SPECIAL_RECIPES
];
// Everything the crafting table offers. RECIPES stay first so journal page indexes (craft_N_0) keep matching.
export const WORKBENCH_RECIPES=[...RECIPES,...JOB_VANILLA_RECIPES,...BASIC_RECIPES];
export const recipeTier=r=>r.level?'special':r.job?'job':'basic';
// Difficulty-based craft XP. Crafted ingredients are valued from the recipe that makes them.
const makers=new Map();for(const r of WORKBENCH_RECIPES)if(!makers.has(r.output[0]))makers.set(r.output[0],r);
const values=new Map();
export function itemValue(type,seen=new Set()){
 if(typeof type!=='string')return GROUP_VALUES[type?.group]??1;
 if(MATERIAL_VALUES[type]!==undefined)return MATERIAL_VALUES[type];
 for(const [g,ids] of Object.entries(GROUPS))if(ids.includes(type))return GROUP_VALUES[g]; // e.g. any planks = 1
 if(values.has(type))return values.get(type);
 const r=makers.get(type);if(!r||seen.has(type))return 1;
 seen.add(type);const v=recipeCost(r,seen)/r.output[1];values.set(type,v);return v;
}
export const recipeCost=(r,seen=new Set())=>r.inputs.reduce((sum,[t,n])=>sum+itemValue(t,new Set(seen))*n,0);
export const recipeXp=r=>r.reversible?0:r.xp??Math.max(1,Math.round(recipeCost(r)*WORKBENCH_RULES.tierMultiplier[recipeTier(r)]/WORKBENCH_RULES.xpDivisor));
export const PRIZES=[{name:'ランタン',item:'minecraft:lantern',amount:2,weight:30},{name:'絵画',item:'minecraft:painting',amount:1,weight:25},{name:'植木鉢',item:'minecraft:flower_pot',amount:2,weight:20},{name:'ポピー',item:'minecraft:poppy',amount:4,weight:15},{name:'名札',item:'minecraft:name_tag',amount:1,weight:8},{name:'称号「街のお宝探し」',title:'街のお宝探し',weight:2}];
/** @type {[string,string,number][]} */
export const DAILY=[['納品する','deliver',1],['クラフト台で製作する','craft',3],['図鑑に新登録','discover',1],['街へ素材を届ける','town',1],['依頼を達成する','quest',1]];
export const CODEX=[['minecraft:sheep','ヒツジ','友好モブ'],['minecraft:cow','ウシ','友好モブ'],['minecraft:chicken','ニワトリ','友好モブ'],['minecraft:wolf','オオカミ','友好モブ'],['minecraft:slime','スライム','敵モブ'],['minecraft:creeper','クリーパー','敵モブ'],['minecraft:cod','タラ','魚'],['minecraft:oak_log','オークの原木','素材']];
export const dayKey=(now=Date.now())=>new Date(now+9*3600000).toISOString().slice(0,10);
// the skill trees live in skill-config.js (one per job, 2026-10-28)
export {SKILL_NODES,skillPoints} from './skill-config.js';
